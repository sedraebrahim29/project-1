import 'package:flutter_bloc/flutter_bloc.dart';
import 'login_state.dart';
import '../../data/auth_repository.dart';
import '../../../../core/network/api_exception.dart';

class LoginCubit extends Cubit<LoginState> {
  final AuthRepository _authRepository;

  LoginCubit({AuthRepository? authRepository})
      : _authRepository = authRepository ?? AuthRepository(),
        super(const LoginState());

  void switchTab(LoginTab tab) {
    emit(state.copyWith(
      activeTab: tab,
      status: LoginStatus.initial,
    ));
  }

  void togglePasswordVisibility() {
    emit(state.copyWith(obscurePassword: !state.obscurePassword));
  }

  /// نداء فعلي لـ /auth/login. التوكن بينحفظ تلقائياً جوا AuthRepository.login
  /// لو نجح. الباك بيرجع نفس الـ 422 لحالتين مختلفتين (بيانات دخول غلط / حساب
  /// لسا قيد المراجعة) وما في حقل مميز بينهم غير نص الرسالة نفسها.
  Future<void> login(String email, String password) async {
    emit(state.copyWith(isLoading: true, status: LoginStatus.loading));

    try {
      await _authRepository.login(email, password);
      emit(state.copyWith(isLoading: false, status: LoginStatus.success));
    } on ApiException catch (e) {
      final isPendingAccount = e.message.toLowerCase().contains('pending');
      if (isPendingAccount) {
        emit(state.copyWith(
          isLoading: false,
          status: LoginStatus.pending,
          pendingMessage: e.message,
        ));
      } else {
        emit(state.copyWith(
          isLoading: false,
          status: LoginStatus.error,
          errorMessage: e.message,
        ));
      }
    } catch (error) {
      emit(state.copyWith(
        isLoading: false,
        status: LoginStatus.error,
        errorMessage: error.toString(),
      ));
    }
  }
}
